
import React, { useState, useCallback } from 'react';
import { ImageFile, AppStatus, ColorProfile } from './types';
import { analyzeColorStyle } from './services/geminiService';
import { generateCubeFile } from './utils/lutGenerator';

const App: React.FC = () => {
  const [images, setImages] = useState<ImageFile[]>([]);
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [error, setError] = useState<string | null>(null);
  const [generatedLut, setGeneratedLut] = useState<string | null>(null);
  const [profile, setProfile] = useState<ColorProfile | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    
    // Fix: Explicitly cast Array.from(FileList) to File[] to resolve 'unknown' type inference in the map callback (line 18 and 21)
    const newFiles = Array.from(e.target.files).slice(0, 5 - images.length) as File[];
    const newImages: ImageFile[] = newFiles.map(file => ({
      id: Math.random().toString(36).substring(2, 11),
      file,
      preview: URL.createObjectURL(file)
    }));

    setImages(prev => [...prev, ...newImages]);
  };

  const removeImage = (id: string) => {
    setImages(prev => prev.filter(img => img.id !== id));
  };

  const convertToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const generateLutWorkflow = async () => {
    if (images.length === 0) return;
    
    try {
      setStatus(AppStatus.ANALYZING);
      setError(null);
      
      const base64Images = await Promise.all(images.map(img => convertToBase64(img.file)));
      const colorProfile = await analyzeColorStyle(base64Images);
      
      setProfile(colorProfile);
      const cubeContent = generateCubeFile(colorProfile);
      setGeneratedLut(cubeContent);
      setStatus(AppStatus.GENERATED);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to analyze images. Please try again.');
      setStatus(AppStatus.ERROR);
    }
  };

  const downloadLut = () => {
    if (!generatedLut) return;
    const blob = new Blob([generatedLut], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'AI_Cinematic_Grade.cube';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <header className="text-center mb-12">
        <h1 className="text-5xl font-black bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent mb-4">
          LUTIFY AI
        </h1>
        <p className="text-neutral-400 text-lg">
          Upload 1-5 cinematic screenshots to generate a matching Premiere Pro LUT.
        </p>
      </header>

      <main className="space-y-8">
        {/* Upload Section */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 transition-all hover:border-neutral-700">
          <div className="flex flex-col items-center justify-center border-2 border-dashed border-neutral-800 rounded-xl py-12 px-6 hover:border-blue-500/50 transition-colors">
            <input
              type="file"
              id="file-upload"
              className="hidden"
              multiple
              accept="image/*"
              onChange={handleFileChange}
              disabled={status === AppStatus.ANALYZING}
            />
            <label 
              htmlFor="file-upload"
              className="cursor-pointer flex flex-col items-center group"
            >
              <div className="w-16 h-16 bg-blue-500/10 text-blue-500 rounded-full flex items-center justify-center mb-4 group-hover:bg-blue-500 group-hover:text-white transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                </svg>
              </div>
              <span className="text-lg font-medium">Click to add reference screenshots</span>
              <span className="text-sm text-neutral-500 mt-1">Maximum 5 images (JPG, PNG)</span>
            </label>
          </div>

          {images.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-8">
              {images.map(img => (
                <div key={img.id} className="relative group aspect-square rounded-lg overflow-hidden border border-neutral-800">
                  <img src={img.preview} alt="Reference" className="w-full h-full object-cover" />
                  <button 
                    onClick={() => removeImage(img.id)}
                    className="absolute top-1 right-1 bg-red-500/80 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Action Button */}
        <div className="flex justify-center">
          <button
            onClick={generateLutWorkflow}
            disabled={images.length === 0 || status === AppStatus.ANALYZING}
            className={`
              px-12 py-4 rounded-full font-bold text-lg transition-all shadow-xl
              ${status === AppStatus.ANALYZING 
                ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed' 
                : 'bg-white text-black hover:bg-blue-400 hover:text-white active:scale-95'}
            `}
          >
            {status === AppStatus.ANALYZING ? (
              <span className="flex items-center gap-3">
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                AI Analyzing Frames...
              </span>
            ) : 'Generate Professional LUT'}
          </button>
        </div>

        {/* Results Section */}
        {status === AppStatus.GENERATED && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-8">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-emerald-400 mb-2 flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                    <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clipRule="evenodd" />
                  </svg>
                  LUT Generated Successfully!
                </h3>
                <p className="text-neutral-300 mb-6">
                  The AI has analyzed your {images.length} screenshots and built a custom .cube profile. You can now use this in Adobe Premiere Pro, DaVinci Resolve, or Final Cut Pro.
                </p>
                <div className="grid grid-cols-2 gap-4 text-sm font-mono bg-black/40 p-4 rounded-lg text-neutral-400">
                  <div>Exposure: {profile?.exposure.toFixed(2)}</div>
                  <div>Contrast: {profile?.contrast.toFixed(2)}</div>
                  <div>Saturation: {profile?.saturation.toFixed(2)}</div>
                  <div>Temp: {profile?.temperature.toFixed(2)}</div>
                </div>
              </div>
              <button
                onClick={downloadLut}
                className="w-full md:w-auto px-8 py-8 bg-emerald-500 hover:bg-emerald-400 text-white rounded-xl font-bold flex flex-col items-center justify-center gap-3 transition-colors shadow-lg shadow-emerald-500/20"
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-10 h-10">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
                </svg>
                Download .CUBE File
              </button>
            </div>
          </div>
        )}

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-4 rounded-xl text-center">
            {error}
          </div>
        )}
      </main>

      <footer className="mt-24 pt-8 border-t border-neutral-900 text-center text-neutral-600 text-sm">
        <p>© 2024 Lutify AI • Powered by Gemini 3 Pro Vision</p>
        <p className="mt-2">Supports Adobe Premiere Pro, After Effects, Photoshop, DaVinci Resolve</p>
      </footer>
    </div>
  );
};

export default App;
