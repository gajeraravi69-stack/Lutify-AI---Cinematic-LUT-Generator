
import { GoogleGenAI, Type } from "@google/genai";
import { ColorProfile } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeColorStyle = async (imageDatas: string[]): Promise<ColorProfile> => {
  const model = 'gemini-3-pro-preview';
  
  const prompt = `Analyze the cinematic color grade of these reference images. 
  Your goal is to provide parameters for a high-quality 3D LUT that replicates this look WITHOUT causing pixel artifacts or harsh clipping.
  
  CRITICAL INSTRUCTIONS:
  - Avoid extreme values that crush blacks or blow out highlights too harshly.
  - The 'lift' should stay very close to 0 (e.g., -0.05 to 0.05).
  - The 'gain' should stay near 1.0 (e.g., 0.8 to 1.3).
  - The 'gamma' should stay near 1.0 (e.g., 0.7 to 1.4).
  - If the reference has very dark areas, slightly lower 'lift' but keep it subtle.
  - Ensure the R, G, B balance in lift/gamma/gain creates the specific color cast (like teal/orange) seen in the reference.

  Output JSON:
  - exposure: (-1.5 to 1.5)
  - contrast: (0.7 to 1.3)
  - saturation: (0.5 to 1.5)
  - temperature: (-0.3 to 0.3)
  - tint: (-0.2 to 0.2)
  - lift: [R, G, B] (Values around 0)
  - gamma: [R, G, B] (Values around 1.0)
  - gain: [R, G, B] (Values around 1.0)`;

  const parts = imageDatas.map(data => ({
    inlineData: {
      mimeType: "image/jpeg",
      data: data.split(',')[1]
    }
  }));

  const response = await ai.models.generateContent({
    model,
    contents: { parts: [...parts, { text: prompt }] },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          exposure: { type: Type.NUMBER },
          contrast: { type: Type.NUMBER },
          saturation: { type: Type.NUMBER },
          temperature: { type: Type.NUMBER },
          tint: { type: Type.NUMBER },
          lift: {
            type: Type.ARRAY,
            items: { type: Type.NUMBER },
            minItems: 3,
            maxItems: 3
          },
          gamma: {
            type: Type.ARRAY,
            items: { type: Type.NUMBER },
            minItems: 3,
            maxItems: 3
          },
          gain: {
            type: Type.ARRAY,
            items: { type: Type.NUMBER },
            minItems: 3,
            maxItems: 3
          }
        },
        required: ["exposure", "contrast", "saturation", "lift", "gamma", "gain"]
      }
    }
  });

  const result = JSON.parse(response.text || "{}");
  
  return {
    exposure: result.exposure ?? 0,
    contrast: result.contrast ?? 1,
    saturation: result.saturation ?? 1,
    vibrance: 1,
    temperature: result.temperature ?? 0,
    tint: result.tint ?? 0,
    highlights: 0,
    shadows: 0,
    redGain: 1,
    greenGain: 1,
    blueGain: 1,
    lift: result.lift || [0, 0, 0],
    gamma: result.gamma || [1, 1, 1],
    gain: result.gain || [1, 1, 1]
  };
};
