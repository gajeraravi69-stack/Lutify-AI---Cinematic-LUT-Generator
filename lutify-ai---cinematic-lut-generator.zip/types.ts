
export interface ColorProfile {
  exposure: number;      // -2 to +2
  contrast: number;      // 0.5 to 1.5
  saturation: number;    // 0 to 2
  vibrance: number;      // 0 to 2
  temperature: number;   // -0.5 to 0.5 (blue to yellow)
  tint: number;          // -0.5 to 0.5 (green to magenta)
  highlights: number;    // -1 to 1
  shadows: number;       // -1 to 1
  redGain: number;       // 0.5 to 1.5
  greenGain: number;     // 0.5 to 1.5
  blueGain: number;      // 0.5 to 1.5
  lift: [number, number, number]; // RGB lift
  gamma: [number, number, number]; // RGB gamma
  gain: [number, number, number];  // RGB gain
}

export interface ImageFile {
  id: string;
  file: File;
  preview: string;
}

export enum AppStatus {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  GENERATED = 'GENERATED',
  ERROR = 'ERROR'
}
