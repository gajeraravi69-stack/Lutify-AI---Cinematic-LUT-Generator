
import { ColorProfile } from '../types';

/**
 * Generates a high-quality 33x33x33 3D LUT in .cube format.
 * Uses refined color science formulas to ensure smooth transitions and avoid artifacts.
 */
export const generateCubeFile = (profile: ColorProfile): string => {
  const size = 33;
  let cubeData = `TITLE "AI Generated Professional Cinematic LUT"\n`;
  cubeData += `LUT_3D_SIZE ${size}\n\n`;

  // Helper: Smoothly clamp values with a soft knee to prevent harsh clipping
  const softClamp = (x: number): number => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    // Basic S-curve like behavior for extreme values
    return x;
  };

  // Improved Lift, Gamma, Gain (Standard ASC CDL inspired but adapted for 0-1 range)
  const applyLGG = (x: number, lift: number, gamma: number, gain: number): number => {
    // Lift: offsets the black point (shadows)
    // Gamma: power function for midtones
    // Gain: multiplier for the white point (highlights)
    let res = x * gain + lift;
    if (res < 0) res = 0;
    return Math.pow(res, 1.0 / Math.max(0.1, gamma));
  };

  // Simple S-Curve for Contrast that preserves mid-point
  const applyContrast = (x: number, contrast: number): number => {
    if (contrast === 1) return x;
    const pivot = 0.5;
    return softClamp((x - pivot) * contrast + pivot);
  };

  for (let b = 0; b < size; b++) {
    for (let g = 0; g < size; g++) {
      for (let r = 0; r < size; r++) {
        // Normalized input values [0, 1]
        let ri = r / (size - 1);
        let gi = g / (size - 1);
        let bi = b / (size - 1);

        // 1. Initial Exposure (Global Offset)
        const expMult = Math.pow(2, profile.exposure);
        ri *= expMult;
        gi *= expMult;
        bi *= expMult;

        // 2. Contrast around 0.5 pivot
        ri = applyContrast(ri, profile.contrast);
        gi = applyContrast(gi, profile.contrast);
        bi = applyContrast(bi, profile.contrast);

        // 3. Per-Channel Lift, Gamma, Gain for Color Grading
        // We use the arrays from the profile [R, G, B]
        ri = applyLGG(ri, profile.lift[0], profile.gamma[0], profile.gain[0]);
        gi = applyLGG(gi, profile.lift[1], profile.gamma[1], profile.gain[1]);
        bi = applyLGG(bi, profile.lift[2], profile.gamma[2], profile.gain[2]);

        // 4. Temperature / Tint Adjustments
        // Temp: Blue-Yellow (-0.5 to 0.5)
        ri += profile.temperature * 0.05;
        bi -= profile.temperature * 0.05;
        // Tint: Green-Magenta (-0.5 to 0.5)
        gi -= profile.tint * 0.05;
        ri += profile.tint * 0.025;
        bi += profile.tint * 0.025;

        // 5. Saturation (Luminance preserving)
        const luma = 0.2126 * ri + 0.7152 * gi + 0.0722 * bi;
        const sat = profile.saturation;
        ri = luma + (ri - luma) * sat;
        gi = luma + (gi - luma) * sat;
        bi = luma + (bi - luma) * sat;

        // Final Safety Clamp
        cubeData += `${softClamp(ri).toFixed(6)} ${softClamp(gi).toFixed(6)} ${softClamp(bi).toFixed(6)}\n`;
      }
    }
  }

  return cubeData;
};
